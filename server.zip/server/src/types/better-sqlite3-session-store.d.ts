declare module 'better-sqlite3-session-store';
